<?php 
	print '    <div class="memberg-photo" style="background-image: url(\''.$fields["field_photo"]->content.'\');" >';
	print '    </div>';
	print '    <div class="memberg-title memberg-field">'.$fields["title"]->content.'</div>';
	print '    <div class="memberg-position memberg-field">'.$fields["field_position"]->content.'</div>';
	print '    <div class="memberg-email memberg-field">'.$fields["field_email"]->content.'</div>';
	print '    <div class="memberg-phone memberg-field">'.$fields["field_phone"]->content.'</div>';
	
	//3 - administrator role id; 4 - editor
	if(user_has_role(3) || user_has_role(4)){ 
		$entity = $row->_field_data["nid"]["entity"];
		print '<div>';
		print '<b>Order:</b> '.$entity->field_order["und"][0]["value"].' <b>Node ID: </b>'.$row->nid.', <b>LNG: </b>'.strtoupper($entity->language == 'und' ? 'neutral' : $entity->language).'<br/>';
		print '<a href="/node/'.$row->nid.'/delete">Remove</a>&nbsp;|&nbsp;';
		print '<a href="/node/'.$row->nid.'/edit">Edit</a>&nbsp;|&nbsp;';
		print '<a href="/node/'.$row->nid.'/translate">Translate</a>';
		print '</div>';
	}
?>
